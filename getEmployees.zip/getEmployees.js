const aws = require('aws-sdk')

const { unmarshall } = require('@aws-sdk/util-dynamodb')

const {
  DynamoDBClient,
  GetItemCommand,
  ScanCommand,
  PutItemCommand,
  UpdateItemCommand
} = require('@aws-sdk/client-dynamodb')

const dbClient =  new DynamoDBClient({ credentials: { secretAccessKey: 'bTwnJ8rtEnGx/ta7WNmZ0ryq56sDYWshZijS6Tdw',
  accessKeyId: 'AKIA6I4X2TNMUJUKV7HO' }, region: 'eu-west-2' })
const TABLE_NAME = 'Employees'

exports.handler = async function (event) {
    
    const employees = getAllEmployees()
    
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify(employees)
    }
    return response
}

async function getAllEmployees() {
  
  let result = await dbClient.send(new ScanCommand({TableName: TABLE_NAME }))
  let response = []
  result.Items.forEach(function(element, index, array){
    response.push(unmarshall(element))
  })
  console.log(response)
  return response
}

